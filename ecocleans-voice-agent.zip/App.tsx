
import React, { useState, useEffect } from 'react';
import { useLiveGemini } from './hooks/useLiveGemini';
import { useChatGemini } from './hooks/useChatGemini';
import { Visualizer } from './components/Visualizer';
import { ServiceCard } from './components/ServiceCard';
import { ChatInterface } from './components/ChatInterface';
import { BookingDetails } from './types';

type Mode = 'voice' | 'text';

const App: React.FC = () => {
  const [mode, setMode] = useState<Mode>('voice');
  const [bookingDetails, setBookingDetails] = useState<BookingDetails>({});
  const [callStartTime, setCallStartTime] = useState<Date | null>(null);

  // Callback to update booking details from either hook
  const handleBookingUpdate = (details: BookingDetails) => {
    setBookingDetails(prev => ({ ...prev, ...details }));
  };

  const { connect, disconnect, connected, volume, error: voiceError } = useLiveGemini({
    onBookingUpdate: handleBookingUpdate
  });

  const { messages, sendMessage, loading: chatLoading } = useChatGemini({
    onBookingUpdate: handleBookingUpdate
  });

  // Auto-disconnect voice when switching to text
  useEffect(() => {
    if (mode === 'text' && connected) {
      disconnect();
    }
  }, [mode, connected, disconnect]);

  const handleToggleCall = () => {
    if (connected) {
      disconnect();
    } else {
      setCallStartTime(new Date());
      connect();
    }
  };

  const formatDate = (date: Date | null) => {
    if (!date) return 'Not started';
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50 relative">
      {/* Header */}
      <header className="flex-none p-4 bg-white border-b border-slate-200 shadow-sm z-20 flex justify-between items-center">
        <div className="flex items-center gap-2">
           <div className="w-8 h-8 bg-teal-600 rounded-lg flex items-center justify-center text-white font-bold">E</div>
           <div>
             <h1 className="text-lg font-bold text-slate-800 leading-none">Ecocleans</h1>
             <p className="text-xs text-slate-500">Voice & Text Agent</p>
           </div>
        </div>
        
        {/* Mode Switcher */}
        <div className="flex bg-slate-100 p-1 rounded-lg">
           <button 
             onClick={() => setMode('voice')}
             className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${mode === 'voice' ? 'bg-white text-teal-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
           >
             Voice
           </button>
           <button 
             onClick={() => setMode('text')}
             className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${mode === 'text' ? 'bg-white text-teal-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
           >
             Text
           </button>
        </div>

        <div className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1.5 ${connected ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>
           <span className={`w-2 h-2 rounded-full ${connected ? 'bg-green-500 animate-pulse' : 'bg-slate-400'}`}></span>
           {connected ? 'Live Call' : 'Offline'}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden flex flex-col md:flex-row relative">
        
        {/* Left Panel: Interaction (Voice or Text) */}
        <div className="flex-1 flex flex-col bg-slate-50 relative overflow-hidden">
          
          {mode === 'voice' && (
            <div className="flex-1 flex flex-col items-center justify-center p-6 gap-8">
              <div className="absolute top-4 left-4 right-4 md:static md:w-full md:max-w-md z-10">
                 <ServiceCard />
              </div>

              <div className="mt-20 md:mt-0 flex flex-col items-center">
                <Visualizer volume={volume} isActive={connected} />
                <p className="mt-6 text-slate-400 text-sm font-medium animate-pulse">
                   {connected ? "Listening for customer details..." : "Ready to connect"}
                </p>
              </div>
              
              {voiceError && (
                <div className="absolute bottom-4 left-4 right-4 p-3 bg-red-50 border border-red-200 text-red-600 text-sm rounded-lg text-center">
                  {voiceError}
                </div>
              )}
            </div>
          )}

          {mode === 'text' && (
             <ChatInterface 
                messages={messages} 
                onSendMessage={sendMessage} 
                loading={chatLoading} 
             />
          )}

          {/* Sticky Footer Button for Voice Mode ONLY */}
          {mode === 'voice' && (
            <div className="flex-none p-4 z-30 flex justify-center pb-8 md:pb-6">
              <button
                onClick={handleToggleCall}
                className={`
                  group relative flex items-center justify-center gap-3 px-8 py-4 rounded-full font-semibold text-lg transition-all shadow-lg hover:shadow-xl active:scale-95
                  ${connected 
                    ? 'bg-red-50 hover:bg-red-100 text-red-600 border border-red-200' 
                    : 'bg-slate-900 hover:bg-slate-800 text-white'
                  }
                `}
              >
                {connected ? (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                    <span>End Call</span>
                  </>
                ) : (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                    <span>Call Ecocleans</span>
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Right Panel: Database Record View (Always visible) */}
        <div className="flex-1 bg-white border-l border-slate-200 flex flex-col h-[40vh] md:h-auto z-10 shadow-lg md:shadow-none">
          <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
            <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
              </svg>
              Customer Database Record
            </h2>
            <span className="text-[10px] text-slate-400 font-mono">ID: {callStartTime ? callStartTime.getTime().toString().slice(-6) : '---'}</span>
          </div>
          
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            
            {/* Call Meta */}
            <div className="bg-slate-50 rounded-lg p-4 border border-slate-100">
               <h3 className="text-xs font-bold text-slate-400 uppercase mb-3">Session Information</h3>
               <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] text-slate-500 font-medium">Session Type</label>
                    <div className="text-sm font-semibold text-slate-800 capitalize">
                       {mode} Interaction
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-medium">Start Time</label>
                    <div className="text-sm font-semibold text-slate-800">
                       {callStartTime ? callStartTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--'}
                    </div>
                  </div>
               </div>
            </div>

            {/* Customer Details */}
            <div>
               <h3 className="text-xs font-bold text-teal-600 uppercase mb-3 flex items-center gap-1">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                 </svg>
                 Customer Details
               </h3>
               <div className="space-y-4">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-white border border-slate-200 rounded p-2">
                      <label className="block text-[10px] text-slate-400 uppercase">Name</label>
                      <div className={`text-sm ${bookingDetails.customerName ? 'text-slate-800 font-medium' : 'text-slate-300 italic'}`}>
                        {bookingDetails.customerName || 'Pending...'}
                      </div>
                    </div>
                    <div className="bg-white border border-slate-200 rounded p-2">
                      <label className="block text-[10px] text-slate-400 uppercase">Phone Number</label>
                      <div className={`text-sm ${bookingDetails.phoneNumber ? 'text-slate-800 font-medium' : 'text-slate-300 italic'}`}>
                        {bookingDetails.phoneNumber || 'Pending...'}
                      </div>
                    </div>
                 </div>
                 <div className="bg-white border border-slate-200 rounded p-2">
                    <label className="block text-[10px] text-slate-400 uppercase">Service Address</label>
                    <div className={`text-sm ${bookingDetails.address ? 'text-slate-800 font-medium' : 'text-slate-300 italic'}`}>
                       {bookingDetails.address || 'Pending...'}
                    </div>
                 </div>
               </div>
            </div>

            {/* Property Details */}
            <div>
               <h3 className="text-xs font-bold text-teal-600 uppercase mb-3 flex items-center gap-1">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                 </svg>
                 Property Information
               </h3>
               <div className="grid grid-cols-3 gap-2">
                  <div className="bg-white border border-slate-200 rounded p-2 text-center">
                    <label className="block text-[10px] text-slate-400 uppercase">Bedrooms</label>
                    <div className={`text-lg font-bold ${bookingDetails.bedrooms ? 'text-slate-800' : 'text-slate-200'}`}>
                      {bookingDetails.bedrooms || '-'}
                    </div>
                  </div>
                  <div className="bg-white border border-slate-200 rounded p-2 text-center">
                    <label className="block text-[10px] text-slate-400 uppercase">Bathrooms</label>
                    <div className={`text-lg font-bold ${bookingDetails.bathrooms ? 'text-slate-800' : 'text-slate-200'}`}>
                      {bookingDetails.bathrooms || '-'}
                    </div>
                  </div>
                  <div className="bg-white border border-slate-200 rounded p-2 text-center">
                    <label className="block text-[10px] text-slate-400 uppercase">Size</label>
                    <div className={`text-sm mt-1 font-medium ${bookingDetails.cleaningSize ? 'text-slate-800' : 'text-slate-300 italic'}`}>
                      {bookingDetails.cleaningSize || 'Pending'}
                    </div>
                  </div>
               </div>
            </div>

            {/* Scheduling */}
            <div>
               <h3 className="text-xs font-bold text-teal-600 uppercase mb-3 flex items-center gap-1">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                 </svg>
                 Scheduled Service
               </h3>
               <div className="bg-teal-50 border border-teal-100 rounded-lg p-4">
                  <div className="mb-3 border-b border-teal-100 pb-2">
                      <label className="block text-[10px] text-teal-600 uppercase font-semibold mb-1">Service Frequency</label>
                      <div className={`text-sm ${bookingDetails.cleaningFrequency ? 'text-teal-900 font-bold' : 'text-teal-300/50 italic'}`}>
                          {bookingDetails.cleaningFrequency || 'Pending...'}
                      </div>
                  </div>
                  <label className="block text-[10px] text-teal-600 uppercase font-semibold mb-1">Date & Time of Schedule</label>
                  <div className={`text-lg ${bookingDetails.scheduleDate ? 'text-teal-900 font-bold' : 'text-teal-300/50 italic'}`}>
                     {bookingDetails.scheduleDate || 'To be determined...'}
                  </div>
               </div>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
