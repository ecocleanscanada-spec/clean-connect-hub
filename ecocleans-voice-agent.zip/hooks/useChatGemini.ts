import { useState, useRef } from 'react';
import { GoogleGenAI, Chat } from '@google/genai';
import { BookingDetails, ChatMessage, Speaker } from '../types';
import { SYSTEM_INSTRUCTION, BOOKING_TOOL } from '../utils/constants';

interface UseChatGeminiProps {
  onBookingUpdate: (details: BookingDetails) => void;
}

export const useChatGemini = ({ onBookingUpdate }: UseChatGeminiProps) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const chatSessionRef = useRef<Chat | null>(null);

  const initChat = () => {
    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) throw new Error("API Key not found");
      const ai = new GoogleGenAI({ apiKey });
      
      chatSessionRef.current = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          tools: [{ functionDeclarations: [BOOKING_TOOL] }],
        }
      });
    } catch (err: any) {
      setError(err.message);
    }
  };

  const sendMessage = async (text: string) => {
    if (!chatSessionRef.current) initChat();
    if (!chatSessionRef.current) return;

    setLoading(true);
    
    // Optimistic UI update
    const userMsgId = Date.now().toString();
    const newMessages = [
      ...messages,
      { id: userMsgId, role: Speaker.USER, text, timestamp: new Date() }
    ];
    setMessages(newMessages);

    try {
      let result = await chatSessionRef.current.sendMessage({ message: text });
      
      // Handle Function Calls loop
      // The model may perform multiple function calls before returning text
      while (result.functionCalls && result.functionCalls.length > 0) {
        const functionResponses = result.functionCalls.map(call => {
           if (call.name === 'update_booking_details') {
             const args = call.args as any;
             onBookingUpdate(args);
             return {
                id: call.id,
                name: call.name,
                response: { result: 'Booking details updated successfully.' }
             };
           }
           return { id: call.id, name: call.name, response: { result: 'Unknown tool.' } };
        });

        // Send function response back to model
        result = await chatSessionRef.current.sendMessage(functionResponses);
      }

      const modelResponseText = result.text;
      
      if (modelResponseText) {
        setMessages(prev => [
          ...prev,
          { id: Date.now().toString(), role: Speaker.MODEL, text: modelResponseText, timestamp: new Date() }
        ]);
      }
    } catch (err: any) {
      console.error("Chat Error:", err);
      setError("Failed to send message.");
      setMessages(prev => [
        ...prev, 
        { id: Date.now().toString(), role: Speaker.SYSTEM, text: "Error: Could not reach Ecocleans agent.", timestamp: new Date() }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return {
    messages,
    sendMessage,
    loading,
    error
  };
};