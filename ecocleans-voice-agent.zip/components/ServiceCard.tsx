import React from 'react';
import { ECO_SERVICES } from '../types';

export const ServiceCard: React.FC = () => {
  return (
    <div className="bg-white/50 backdrop-blur-md rounded-xl p-4 border border-white/60 shadow-sm max-h-[200px] overflow-y-auto">
      <h3 className="text-sm font-semibold text-slate-500 mb-2 uppercase tracking-wider">Available Services</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {ECO_SERVICES.map(service => (
          <div key={service.id} className="text-xs p-2 bg-white rounded border border-slate-100">
            <span className="font-bold text-teal-700">{service.name}</span>
            <p className="text-slate-500 truncate">{service.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};